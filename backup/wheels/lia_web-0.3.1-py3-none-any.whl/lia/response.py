# Re-export from cross_web for backwards compatibility
from cross_web.response import Cookie, Response

__all__ = ["Cookie", "Response"]
