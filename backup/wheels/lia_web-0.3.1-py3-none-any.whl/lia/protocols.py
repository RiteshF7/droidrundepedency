# Re-export from cross_web for backwards compatibility
from cross_web.protocols import BaseRequestProtocol

__all__ = ["BaseRequestProtocol"]
