# Re-export from cross_web for backwards compatibility
from cross_web.exceptions import HTTPException

__all__ = ["HTTPException"]
