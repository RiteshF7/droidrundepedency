# Re-export from cross_web for backwards compatibility
from cross_web.request import AsyncHTTPRequest

__all__ = ["AsyncHTTPRequest"]
