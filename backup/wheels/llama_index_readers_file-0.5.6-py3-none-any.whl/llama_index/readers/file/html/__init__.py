from llama_index.readers.file.html.base import HTMLTagReader

__all__ = ["HTMLTagReader"]
