"""Init file."""

from llama_index.readers.file.pymu_pdf.base import (
    PyMuPDFReader,
)

__all__ = ["PyMuPDFReader"]
