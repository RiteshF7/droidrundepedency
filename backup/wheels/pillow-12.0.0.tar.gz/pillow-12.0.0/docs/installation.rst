:orphan:

Installation
============

Basic installation
------------------

.. Note:: This section has moved to :ref:`basic-installation`. Please update references accordingly.

Python support
--------------

.. Note:: This section has moved to :ref:`python-support`. Please update references accordingly.

Platform support
----------------

.. Note:: This section has moved to :ref:`platform-support`. Please update references accordingly.

Building from source
--------------------

.. Note:: This section has moved to :ref:`building-from-source`. Please update references accordingly.

Old versions
------------

.. Note:: This section has moved to :ref:`old-versions`. Please update references accordingly.
