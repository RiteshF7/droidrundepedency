class ResourceAttributes:
    PROJECT_NAME = "openinference.project.name"
