from phoenix.trace.v1.evaluation_pb2 import Evaluation

__all__ = [
    "Evaluation",
]
