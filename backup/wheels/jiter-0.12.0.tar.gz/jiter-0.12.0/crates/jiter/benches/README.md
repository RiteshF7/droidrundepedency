# Benchmarks

Before running benchmarks, make sure to generate `big.json`:

```shell
python3 ./crates/jiter/benches/generate_big.py
```

To run benchmarks, run:

```shell
cargo bench -p jiter
```
