VERSION = "7.4.2"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201
